package app.mediadownloader

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class Ui(val item: Item, val live: Live?)
data class FS(val url: String, val loading: Boolean = true, val meta: Meta? = null, val error: String = "")
data class PL(
    val loading: Boolean = false,
    val url: String = "",
    val title: String = "",
    val entries: List<Entry> = emptyList(),
    val sel: Set<Int> = emptySet(),
    val error: String = ""
)

fun urls(t: String): List<String> {
    val found = Regex("""(?i)\b(?:https?|ftp)://[^\s<>"']+""").findAll(t).map { it.value }.toList()
    return found.ifEmpty { t.lines().map { it.trim() }.filter { it.isNotEmpty() } }.distinct()
}

class VM(private val ctx: Application) : AndroidViewModel(ctx) {
    private val m = (ctx as App).mgr
    private val cfgFlow: Flow<Cfg?> = m.repo.flow

    val cfg: StateFlow<Cfg?> = cfgFlow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val items: StateFlow<List<Ui>> = combine(m.dao.items(), m.live) { l, lv -> l.map { Ui(it, lv[it.id]) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val subs: StateFlow<List<Sub>> = m.dao.subs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val ready = Engine.ready
    val engineError = Engine.error
    val engineVersion = Engine.version
    val engineBusy = MutableStateFlow(false)
    val engineMsg = MutableStateFlow("")
    val formats = MutableStateFlow<FS?>(null)
    val pl = MutableStateFlow(PL())
    val busySubs = MutableStateFlow<Set<Long>>(emptySet())
    val subMsg = MutableStateFlow("")

    private fun io(b: suspend CoroutineScope.() -> Unit): Job = viewModelScope.launch(Dispatchers.IO, block = b)

    fun set(f: (Cfg) -> Cfg) {
        io { m.repo.update(f) }
    }

    fun add(text: String, preset: String) {
        io {
            val c = m.repo.flow.first()
            val a = presetArgs(c, preset.ifEmpty { c.preset })
            urls(text).forEach { m.enqueue(Item(url = it, args = a)) }
        }
    }

    fun importFile(uri: Uri, preset: String) {
        io {
            val t = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return@io
            val c = m.repo.flow.first()
            val a = presetArgs(c, preset)
            urls(t).forEach { m.enqueue(Item(url = it, args = a)) }
        }
    }

    fun start(id: Long) = m.startItem(id)
    fun cancel(id: Long) = m.cancel(id)
    fun remove(id: Long) = m.remove(id)
    fun deleteFile(i: Item) = m.deleteFile(i.id)
    fun cancelAll() = m.cancelAll()

    fun startAll() {
        io {
            m.dao.startAll()
            m.pump()
        }
    }

    fun clearEnded() {
        io { m.dao.clearEnded() }
    }

    fun fetchFormats(t: String) {
        val u = urls(t).firstOrNull() ?: return
        formats.value = FS(u)
        io {
            val c = m.repo.flow.first()
            val r = try {
                FS(u, false, Engine.meta(Engine.dump(u, c, m.cookies, null, true, true)))
            } catch (e: Throwable) {
                FS(u, false, null, brief(e))
            }
            formats.update { if (it?.url == u) r else it }
        }
    }

    fun closeFormats() {
        formats.value = null
    }

    fun addFormat(spec: String) {
        val s = formats.value ?: return
        formats.value = null
        io {
            val mt = s.meta
            m.enqueue(
                Item(
                    url = s.url,
                    title = mt?.title.orEmpty(),
                    thumb = mt?.thumb.orEmpty(),
                    uploader = mt?.uploader.orEmpty(),
                    duration = mt?.duration ?: 0,
                    args = "-f $spec"
                )
            )
        }
    }

    fun fetchPlaylist(u: String) {
        pl.value = PL(loading = true, url = u)
        io {
            val c = m.repo.flow.first()
            val r = try {
                val p = Engine.playlist(Engine.dump(u, c, m.cookies, null, true, false))
                PL(url = u, title = p.title, entries = p.entries, sel = p.entries.map { it.index }.toSet())
            } catch (e: Throwable) {
                PL(url = u, error = brief(e))
            }
            pl.update { if (it.url == u) r else it }
        }
    }

    fun toggle(i: Int) {
        pl.update { it.copy(sel = if (i in it.sel) it.sel - i else it.sel + i) }
    }

    fun selAll() {
        pl.update { s -> s.copy(sel = s.entries.map { it.index }.toSet()) }
    }

    fun selNone() {
        pl.update { it.copy(sel = emptySet()) }
    }

    fun selRange(a: Int, b: Int) {
        pl.update { s -> s.copy(sel = s.entries.map { it.index }.filter { it in minOf(a, b)..maxOf(a, b) }.toSet()) }
    }

    fun addSelected(preset: String) {
        io {
            val c = m.repo.flow.first()
            val s = pl.value
            val a = presetArgs(c, preset)
            s.entries.filter { it.index in s.sel }.forEach { e ->
                m.enqueue(
                    if (e.url.startsWith("http")) Item(url = e.url, title = e.title, thumb = e.thumb, duration = e.duration, args = a)
                    else Item(url = s.url, title = e.title, args = a, playlistItems = e.index.toString())
                )
            }
        }
    }

    fun addSub(u: String, preset: String) {
        io {
            val c = m.repo.flow.first()
            val id = m.dao.addSub(Sub(url = u.trim(), args = presetArgs(c, preset)))
            runCheck(id)
        }
    }

    private suspend fun runCheck(id: Long) {
        busySubs.update { it + id }
        val e = m.checkSub(id)
        subMsg.value = e
        busySubs.update { it - id }
    }

    fun checkSub(id: Long) {
        io { runCheck(id) }
    }

    fun checkAllSubs() {
        io { m.dao.subList().forEach { runCheck(it.id) } }
    }

    fun downloadNew(id: Long) {
        io { m.consumeSub(id, true) }
    }

    fun markSeen(id: Long) {
        io { m.consumeSub(id, false) }
    }

    fun delSub(id: Long) {
        io { m.dao.delSub(id) }
    }

    fun importCookies(uri: Uri) {
        io {
            ctx.contentResolver.openInputStream(uri)?.use { i -> m.cookies.outputStream().use { o -> i.copyTo(o) } }
            m.repo.update { it.copy(cookies = true) }
        }
    }

    fun clearCookies() {
        io {
            m.cookies.delete()
            m.repo.update { it.copy(cookies = false) }
        }
    }

    fun updateEngine() {
        io {
            engineBusy.value = true
            engineMsg.value = m.updateEngine()
            engineBusy.value = false
        }
    }
}
