package app.mediadownloader

import android.annotation.SuppressLint
import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

data class Live(val p: Float = -1f, val eta: Long = -1, val speed: String = "", val stage: String = "")

private val SPEED = Regex("""at\s+([\d.]+\s?\S*B/s)""")
private val ARIA = Regex("""DL:([\d.]+\S*B)""")
private val POST = Regex("""^\[(Merger|ExtractAudio|VideoConvertor|VideoRemuxer|EmbedThumbnail|Metadata|EmbedSubtitle|SponsorBlock|ModifyChapters|ThumbnailsConvertor|SubtitlesConvertor|MoveFiles|Fixup\w*)\]""")
private val JUNK = setOf("part", "ytdl", "temp", "tmp", "aria2", "json")
private val MEDIA = setOf("mp4", "mkv", "webm", "m4a", "mp3", "opus", "ogg", "flac", "wav", "aac", "mov", "avi", "flv", "ts", "m4v", "3gp", "wma", "wmv", "mpg", "mpeg", "weba")

private fun speedOf(l: String): String? =
    SPEED.find(l)?.groupValues?.get(1) ?: ARIA.find(l)?.groupValues?.get(1)?.let { "$it/s" }

private fun stageOf(l: String): String? =
    if (POST.containsMatchIn(l)) "post" else if (l.startsWith("[download]")) "" else null

fun brief(e: Throwable): String {
    val m = e.message ?: e.javaClass.simpleName
    return m.lines().lastOrNull { it.contains("ERROR") }?.trim() ?: m.trim().takeLast(500)
}

class Manager(val app: Application) {
    val repo = Repo(app)
    val dao = Db.get(app).dao()
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val live = MutableStateFlow<Map<Long, Live>>(emptyMap())
    val active = MutableStateFlow(0)
    val cookies = File(app.filesDir, "cookies.txt")
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val canceled: MutableSet<Long> = ConcurrentHashMap.newKeySet()
    private val lock = Mutex()
    private val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun boot() {
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    pump()
                }
            })
        } catch (e: Throwable) {
        }
        scope.launch {
            dao.requeue()
            Engine.init(app)
            if (Engine.ready.value) {
                Engine.refreshVersion()
                pump()
                val c = repo.flow.first()
                if (c.autoUpdate && System.currentTimeMillis() - c.lastUpdate > 86_400_000L) updateEngine()
            }
        }
    }

    suspend fun updateEngine(): String {
        val c = repo.flow.first()
        val r = try {
            Engine.update(app, c.channel)
        } catch (e: Throwable) {
            brief(e)
        }
        repo.update { it.copy(lastUpdate = System.currentTimeMillis()) }
        return r
    }

    private fun unmetered(): Boolean {
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    fun pump() {
        scope.launch {
            lock.withLock {
                if (!Engine.ready.value) return@withLock
                val c = repo.flow.first()
                if (c.unmetered && !unmetered()) return@withLock
                val free = c.parallel - jobs.size
                if (free <= 0) return@withLock
                for (item in dao.queued().filter { !jobs.containsKey(it.id) }.take(free)) launchJob(item, c)
            }
        }
    }

    private fun kick() {
        try {
            ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        } catch (e: Throwable) {
        }
    }

    private fun launchJob(item: Item, c: Cfg) {
        val job = scope.launch(start = CoroutineStart.LAZY) {
            try {
                process(item, c)
            } finally {
                jobs.remove(item.id)
                canceled.remove(item.id)
                live.update { it - item.id }
                active.value = jobs.size
                pump()
            }
        }
        jobs[item.id] = job
        active.value = jobs.size
        kick()
        job.start()
    }

    private suspend fun process(first: Item, c: Cfg) {
        var cur = first
        val id = first.id
        val pid = "dl-$id"
        val dir = File(app.getExternalFilesDir(null) ?: app.filesDir, "tmp/$id")
        val log = StringBuilder()
        try {
            dir.deleteRecursively()
            dir.mkdirs()
            if (cur.title.isBlank()) {
                cur = cur.copy(status = St.FETCHING, error = "")
                dao.save(cur)
                val mt = Engine.meta(Engine.dump(cur.url, c, cookies, pid, true, c.noPlaylist && cur.playlistItems.isBlank()))
                cur = cur.copy(title = mt.title.ifBlank { cur.url }, thumb = mt.thumb, uploader = mt.uploader, duration = mt.duration)
            }
            cur = cur.copy(status = St.RUNNING, error = "")
            dao.save(cur)
            live.update { it + (id to Live()) }
            val resp = Engine.run(Engine.request(cur, c, dir, cookies), pid) { p, eta, line ->
                if (log.length < 100_000 && !(line.startsWith("[download]") && line.contains('%'))) log.appendLine(line)
                live.update { m ->
                    val o = m[id] ?: Live()
                    m + (id to Live(if (p >= 0f) p else o.p, if (eta >= 0) eta else o.eta, speedOf(line) ?: o.speed, stageOf(line) ?: o.stage))
                }
            }
            log.append(resp.err.takeLast(4000))
            val files = dir.walkTopDown().filter { it.isFile && it.extension.lowercase() !in JUNK }.sortedByDescending { it.length() }.toList()
            if (files.isEmpty()) throw IllegalStateException("No output file")
            val main = files.firstOrNull { it.extension.lowercase() in MEDIA } ?: files.first()
            var uri = ""
            for (f in files) {
                val u = Out.export(app, f, c.tree)
                if (f == main) uri = u
            }
            cur = cur.copy(status = St.DONE, outUri = uri, outName = main.name, size = main.length(), error = "", log = log.toString().takeLast(20000))
            dao.save(cur)
            Notif.done(app, cur)
        } catch (e: Throwable) {
            val user = canceled.contains(id) || e is YoutubeDL.CanceledException
            if (!user) log.appendLine(e.message.orEmpty())
            cur = cur.copy(status = if (user) St.CANCELED else St.FAILED, error = if (user) "" else brief(e), log = log.toString().takeLast(20000))
            try {
                dao.save(cur)
            } catch (x: Throwable) {
            }
        } finally {
            dir.deleteRecursively()
        }
    }

    suspend fun enqueue(i: Item) {
        val c = repo.flow.first()
        dao.add(i.copy(status = if (c.autoStart) St.QUEUED else St.IDLE))
        if (c.autoStart) pump()
    }

    fun startItem(id: Long) {
        scope.launch {
            dao.item(id)?.let { dao.save(it.copy(status = St.QUEUED, error = "")) }
            pump()
        }
    }

    fun cancel(id: Long) {
        canceled.add(id)
        Engine.cancel("dl-$id")
        scope.launch {
            if (!jobs.containsKey(id)) {
                canceled.remove(id)
                dao.item(id)?.let { if (it.status == St.QUEUED || it.status == St.IDLE) dao.save(it.copy(status = St.CANCELED)) }
            }
        }
    }

    fun cancelAll() {
        scope.launch {
            dao.cancelWaiting()
            jobs.keys.toList().forEach { cancel(it) }
        }
    }

    fun remove(id: Long) {
        cancel(id)
        scope.launch { dao.del(id) }
    }

    fun deleteFile(id: Long) {
        scope.launch {
            dao.item(id)?.let { Out.delete(app, it.outUri) }
            dao.del(id)
        }
    }

    suspend fun checkSub(id: Long): String {
        val s = dao.sub(id) ?: return ""
        val c = repo.flow.first()
        return try {
            val p = Engine.playlist(Engine.dump(s.url, c, cookies, null, true, false))
            val seen = s.seen.lineSequence().filter { it.isNotEmpty() }.toHashSet()
            val fresh = p.entries.filter { it.id !in seen && it.url.startsWith("http") }
            val pending = fresh.joinToString("\n") { "${it.id}\t${it.url}\t${it.title.replace('\t', ' ').replace('\n', ' ')}" }
            dao.saveSub(s.copy(title = p.title.ifBlank { s.title }, total = p.entries.size, pending = pending, checked = System.currentTimeMillis()))
            ""
        } catch (e: Throwable) {
            brief(e)
        }
    }

    suspend fun consumeSub(id: Long, download: Boolean) {
        val s = dao.sub(id) ?: return
        val rows = s.pending.lines().filter { it.isNotBlank() }.map { it.split('\t') }
        if (download) rows.forEach { r -> enqueue(Item(url = r.getOrElse(1) { "" }, title = r.getOrElse(2) { "" }, args = s.args)) }
        dao.saveSub(s.copy(seen = s.seen + rows.joinToString("") { it[0] + "\n" }, pending = ""))
    }
}

object Out {
    private val EXTRA = mapOf(
        "srt" to "application/x-subrip",
        "vtt" to "text/vtt",
        "mkv" to "video/x-matroska",
        "opus" to "audio/ogg",
        "m4a" to "audio/mp4",
        "webm" to "video/webm"
    )

    fun safe(n: String): String = n.replace(Regex("""[\\/:*?"<>|]"""), "_").trim().ifEmpty { "file" }

    fun mime(name: String): String {
        val e = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(e) ?: EXTRA[e] ?: "application/octet-stream"
    }

    fun export(c: Context, f: File, tree: String): String {
        val name = safe(f.name)
        val mt = mime(name)
        if (tree.isNotEmpty()) {
            val dir = DocumentFile.fromTreeUri(c, Uri.parse(tree)) ?: throw IOException("Folder unavailable")
            val d = dir.createFile(mt, name) ?: throw IOException("Cannot create file")
            c.contentResolver.openOutputStream(d.uri)?.use { o -> f.inputStream().use { it.copyTo(o, 1 shl 16) } }
                ?: throw IOException("Cannot write file")
            return d.uri.toString()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val r = c.contentResolver
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mt)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MediaDownloader")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val u = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Cannot create file")
            r.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o, 1 shl 16) } }
                ?: throw IOException("Cannot write file")
            v.clear()
            v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            r.update(u, v, null, null)
            return u.toString()
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MediaDownloader")
        dir.mkdirs()
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var t = File(dir, name)
        var n = 1
        while (t.exists()) {
            t = File(dir, if (ext.isEmpty()) "$base ($n)" else "$base ($n).$ext")
            n++
        }
        f.copyTo(t)
        MediaScannerConnection.scanFile(c, arrayOf(t.path), null, null)
        return t.absolutePath
    }

    fun uri(c: Context, s: String): Uri =
        if (s.startsWith("/")) FileProvider.getUriForFile(c, c.packageName + ".fp", File(s)) else Uri.parse(s)

    fun view(c: Context, i: Item): Intent =
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri(c, i.outUri), mime(i.outName))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

    fun send(c: Context, i: Item): Intent {
        val s = Intent(Intent.ACTION_SEND)
            .setType(mime(i.outName))
            .putExtra(Intent.EXTRA_STREAM, uri(c, i.outUri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return Intent.createChooser(s, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun delete(c: Context, s: String) {
        try {
            if (s.isEmpty()) return
            if (s.startsWith("/")) {
                File(s).delete()
            } else {
                val u = Uri.parse(s)
                if (u.authority == MediaStore.AUTHORITY) c.contentResolver.delete(u, null, null)
                else DocumentFile.fromSingleUri(c, u)?.delete()
            }
        } catch (e: Throwable) {
        }
    }
}

object Notif {
    const val CH_RUN = "run"
    const val CH_DONE = "done"

    fun channels(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_RUN, c.getString(R.string.n_run), NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, c.getString(R.string.n_done), NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    fun ongoing(c: Context, n: Int, pct: Int): Notification {
        val openIntent = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(c, 1, Intent(c, DownloadService::class.java).setAction("cancel_all"), PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(c, CH_RUN)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(c.getString(R.string.app_name))
            .setContentText(c.getString(R.string.n_active, n))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent)
            .addAction(0, c.getString(R.string.cancel_all), stop)
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    @SuppressLint("MissingPermission")
    fun done(c: Context, i: Item) {
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        val pi = try {
            PendingIntent.getActivity(c, i.id.toInt(), Out.view(c, i), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        } catch (e: Throwable) {
            null
        }
        val b = NotificationCompat.Builder(c, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(c.getString(R.string.n_done))
            .setContentText(i.outName.ifBlank { i.title })
            .setAutoCancel(true)
        if (pi != null) b.setContentIntent(pi)
        nm.notify(1000 + i.id.toInt(), b.build())
    }
}

@SuppressLint("MissingPermission")
class DownloadService : Service() {
    private var jobs: List<Job> = emptyList()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val m = (application as App).mgr
        ServiceCompat.startForeground(this, 1, Notif.ongoing(this, m.active.value, -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (intent?.action == "cancel_all") m.cancelAll()
        jobs.forEach { it.cancel() }
        jobs = listOf(
            m.scope.launch {
                combine(m.active, m.live) { a, l ->
                    a to (if (l.isEmpty()) -1 else l.values.map { it.p.coerceAtLeast(0f) }.average().toInt())
                }.collect { (a, p) ->
                    NotificationManagerCompat.from(this@DownloadService).notify(1, Notif.ongoing(this@DownloadService, a, p))
                }
            },
            m.scope.launch {
                m.active.collectLatest {
                    if (it == 0) {
                        delay(4000)
                        stopSelf()
                    }
                }
            }
        )
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        jobs.forEach { it.cancel() }
        super.onDestroy()
    }
}
