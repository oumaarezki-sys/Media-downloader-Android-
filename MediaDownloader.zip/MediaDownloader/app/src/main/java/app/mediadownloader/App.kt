package app.mediadownloader

import android.app.Application

class App : Application() {
    lateinit var mgr: Manager

    override fun onCreate() {
        super.onCreate()
        Notif.channels(this)
        mgr = Manager(this)
        mgr.boot()
    }
}
