package app.mediadownloader

import android.content.Context
import android.content.Intent
import android.os.Build
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import java.util.Locale

@Composable
fun AppTheme(c: Cfg, content: @Composable () -> Unit) {
    val dark = when (c.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val act = ctx as? ComponentActivity
    LaunchedEffect(dark) {
        val bar = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        act?.enableEdgeToEdge(statusBarStyle = bar, navigationBarStyle = bar)
    }
    val scheme = when {
        c.dynColor && Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(0xFF90CAF9))
        else -> lightColorScheme(primary = Color(0xFF1565C0))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root(vm: VM, cfg: Cfg) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val fm by vm.formats.collectAsStateWithLifecycle()
    val tabs = listOf(
        Icons.Filled.Download to R.string.tab_dl,
        Icons.Filled.VideoLibrary to R.string.tab_pl,
        Icons.Filled.Subscriptions to R.string.tab_subs,
        Icons.Filled.Settings to R.string.tab_set
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.first, null) },
                        label = { Text(stringResource(t.second), maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).consumeWindowInsets(pad).imePadding()) {
            when (tab) {
                0 -> DownloadsScreen(vm, cfg)
                1 -> PlaylistScreen(vm, cfg)
                2 -> SubsScreen(vm, cfg)
                else -> SettingsScreen(vm, cfg)
            }
        }
    }
    fm?.let { FormatsDialog(vm, it) }
}

@Composable
fun IB(icon: ImageVector, desc: Int, enabled: Boolean = true, on: () -> Unit) {
    IconButton(onClick = on, enabled = enabled) { Icon(icon, stringResource(desc)) }
}

@Composable
fun Header(title: Int, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(stringResource(title), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun Dd(label: String, options: List<Pair<String, String>>, sel: String, on: (String) -> Unit) {
    var exp by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { exp = true }) {
            Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Icon(Icons.Filled.ArrowDropDown, null)
        }
        DropdownMenu(expanded = exp, onDismissRequest = { exp = false }) {
            options.forEach { (k, t) ->
                DropdownMenuItem(
                    text = { Text(t) },
                    onClick = {
                        on(k)
                        exp = false
                    },
                    trailingIcon = { if (k == sel) Icon(Icons.Filled.Check, null) }
                )
            }
        }
    }
}

@Composable
fun presetLabel(p: Preset): String = if (p.name == "best") stringResource(R.string.best) else p.name

@Composable
fun PresetPicker(cfg: Cfg, sel: String, on: (String) -> Unit) {
    val all = allPresets(cfg)
    val cur = all.firstOrNull { it.name == sel } ?: all[0]
    Dd(presetLabel(cur), all.map { it.name to presetLabel(it) }, cur.name, on)
}

fun hms(s: Long): String {
    val h = s / 3600
    val m = s % 3600 / 60
    val x = s % 60
    return if (h > 0) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, x) else String.format(Locale.ROOT, "%d:%02d", m, x)
}

fun launchSafe(c: Context, i: Intent) {
    try {
        c.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(c, R.string.no_app, Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun statusLine(u: Ui): String {
    val i = u.item
    val l = u.live
    val ctx = LocalContext.current
    return when (i.status) {
        St.IDLE -> stringResource(R.string.s_idle)
        St.QUEUED -> stringResource(R.string.s_queued)
        St.FETCHING -> stringResource(R.string.s_fetching)
        St.RUNNING -> when {
            l == null -> stringResource(R.string.s_starting)
            l.stage == "post" -> stringResource(R.string.s_post)
            else -> listOfNotNull(
                if (l.p >= 0f) String.format(Locale.ROOT, "%.1f%%", l.p) else null,
                l.speed.ifEmpty { null },
                if (l.eta >= 0) "ETA " + hms(l.eta) else null
            ).joinToString(" · ").ifEmpty { stringResource(R.string.s_starting) }
        }
        St.DONE -> listOf(Formatter.formatShortFileSize(ctx, i.size), i.outName).filter { it.isNotEmpty() }.joinToString(" · ")
        St.FAILED -> i.error.ifBlank { stringResource(R.string.s_failed) }
        St.CANCELED -> stringResource(R.string.s_canceled)
        else -> ""
    }
}

@Composable
fun DownloadsScreen(vm: VM, cfg: Cfg) {
    val list by vm.items.collectAsStateWithLifecycle()
    val ready by vm.ready.collectAsStateWithLifecycle()
    val err by vm.engineError.collectAsStateWithLifecycle()
    val clip = LocalClipboardManager.current
    var text by rememberSaveable { mutableStateOf("") }
    var preset by rememberSaveable(cfg.preset) { mutableStateOf(cfg.preset) }
    var log by remember { mutableStateOf<Item?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.importFile(u, preset)
    }
    Column(Modifier.fillMaxSize()) {
        Header(R.string.tab_dl) {
            IB(Icons.Filled.PlayArrow, R.string.start_all) { vm.startAll() }
            IB(Icons.Filled.Stop, R.string.cancel_all) { vm.cancelAll() }
            IB(Icons.Filled.DeleteSweep, R.string.clear_ended) { vm.clearEnded() }
        }
        if (!ready) {
            if (err.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth())
            else Text(
                stringResource(R.string.engine_error, err),
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(12.dp),
                maxLines = 5,
                overflow = TextOverflow.Ellipsis
            )
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Column {
                    OutlinedTextField(
                        text,
                        { text = it },
                        Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.urls)) },
                        minLines = 2,
                        maxLines = 5,
                        trailingIcon = {
                            IB(Icons.Filled.ContentPaste, R.string.paste) {
                                clip.getText()?.text?.let { text = if (text.isBlank()) it else text.trimEnd() + "\n" + it }
                            }
                        }
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PresetPicker(cfg, preset) { preset = it }
                        IB(Icons.Filled.Tune, R.string.formats, text.isNotBlank()) { vm.fetchFormats(text) }
                        IB(Icons.Filled.FileOpen, R.string.import_file) { picker.launch(arrayOf("*/*")) }
                        Spacer(Modifier.weight(1f))
                        Button(
                            onClick = {
                                vm.add(text, preset)
                                text = ""
                            },
                            enabled = text.isNotBlank()
                        ) {
                            Icon(Icons.Filled.Add, null)
                            Spacer(Modifier.width(4.dp))
                            Text(stringResource(R.string.add))
                        }
                    }
                }
            }
            items(list, key = { it.item.id }) { u -> ItemCard(u, vm) { log = it } }
        }
    }
    log?.let { LogDialog(it) { log = null } }
}

@Composable
fun ItemCard(u: Ui, vm: VM, onLog: (Item) -> Unit) {
    val i = u.item
    val l = u.live
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            Row {
                AsyncImage(
                    model = i.thumb.ifEmpty { null },
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(width = 112.dp, height = 63.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        i.title.ifBlank { i.url },
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        statusLine(u),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (i.status == St.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (i.status == St.FETCHING || (i.status == St.RUNNING && (l == null || l.p < 0f || l.stage == "post"))) {
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
            } else if (i.status == St.RUNNING && l != null) {
                LinearProgressIndicator(progress = { l.p / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                when (i.status) {
                    St.IDLE, St.FAILED, St.CANCELED -> IB(Icons.Filled.PlayArrow, R.string.a_start) { vm.start(i.id) }
                    St.QUEUED, St.FETCHING, St.RUNNING -> IB(Icons.Filled.Close, R.string.a_cancel) { vm.cancel(i.id) }
                    St.DONE -> {
                        IB(Icons.Filled.PlayCircle, R.string.a_open) { launchSafe(ctx, Out.view(ctx, i)) }
                        IB(Icons.Filled.Share, R.string.a_share) { launchSafe(ctx, Out.send(ctx, i)) }
                    }
                    else -> {}
                }
                Box {
                    IB(Icons.Filled.MoreVert, R.string.more) { menu = true }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.a_log)) },
                            onClick = {
                                menu = false
                                onLog(i)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.a_copy)) },
                            onClick = {
                                menu = false
                                clip.setText(AnnotatedString(i.url))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.a_remove)) },
                            onClick = {
                                menu = false
                                vm.remove(i.id)
                            }
                        )
                        if (i.status == St.DONE) DropdownMenuItem(
                            text = { Text(stringResource(R.string.a_delete)) },
                            onClick = {
                                menu = false
                                vm.deleteFile(i)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LogDialog(i: Item, close: () -> Unit) {
    AlertDialog(
        onDismissRequest = close,
        confirmButton = { TextButton(onClick = close) { Text(stringResource(R.string.close)) } },
        title = { Text(i.title.ifBlank { i.url }, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            SelectionContainer {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        (i.error + "\n\n" + i.log).trim().ifEmpty { "-" },
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }
    )
}

fun formatSpec(vids: List<Fmt>, v: String?, a: String?): String = when {
    v != null && a != null -> "$v+$a"
    v != null -> if (vids.firstOrNull { it.id == v }?.hasA == true) v else "$v+ba/$v"
    else -> a ?: ""
}

@Composable
fun FormatsDialog(vm: VM, s: FS) {
    var v by remember { mutableStateOf<String?>(null) }
    var a by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    val fs = s.meta?.formats.orEmpty()
    val vids = fs.filter { it.hasV }.sortedWith(compareByDescending<Fmt> { it.h }.thenByDescending { it.tbr })
    val auds = fs.filter { !it.hasV && it.hasA }.sortedByDescending { it.tbr }
    AlertDialog(
        onDismissRequest = { vm.closeFormats() },
        title = { Text(s.meta?.title?.ifBlank { null } ?: s.url, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            when {
                s.loading -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                s.error.isNotEmpty() -> Text(s.error, color = MaterialTheme.colorScheme.error, maxLines = 8, overflow = TextOverflow.Ellipsis)
                else -> LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    item { Text(stringResource(R.string.fm_video), style = MaterialTheme.typography.titleSmall) }
                    items(vids) { f -> FmtRow(f, f.id == v, ctx) { v = if (v == f.id) null else f.id } }
                    item { Text(stringResource(R.string.fm_audio), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp)) }
                    items(auds) { f -> FmtRow(f, f.id == a, ctx) { a = if (a == f.id) null else f.id } }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !s.loading && (v != null || a != null),
                onClick = { vm.addFormat(formatSpec(vids, v, a)) }
            ) { Text(stringResource(R.string.add)) }
        },
        dismissButton = { TextButton(onClick = { vm.closeFormats() }) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun FmtRow(f: Fmt, sel: Boolean, ctx: Context, click: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = click).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = sel, onClick = null)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(
                listOfNotNull(f.id, f.ext, f.res.ifEmpty { null }, if (f.fps > 0) "${f.fps.toInt()}fps" else null).joinToString(" · "),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                listOfNotNull(
                    f.note.ifEmpty { null },
                    f.vcodec.takeIf { f.hasV && it.isNotEmpty() },
                    f.acodec.takeIf { f.hasA && it.isNotEmpty() },
                    if (f.size > 0) Formatter.formatShortFileSize(ctx, f.size) else null
                ).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
