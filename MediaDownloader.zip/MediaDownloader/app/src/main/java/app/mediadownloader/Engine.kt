package app.mediadownloader

import android.app.Application
import android.content.Context
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File

data class Fmt(
    val id: String,
    val ext: String,
    val res: String,
    val h: Int,
    val fps: Double,
    val vcodec: String,
    val acodec: String,
    val size: Long,
    val tbr: Double,
    val note: String
) {
    val hasV: Boolean get() = vcodec != "none"
    val hasA: Boolean get() = acodec != "none"
}

data class Entry(val index: Int, val id: String, val url: String, val title: String, val duration: Long, val thumb: String)
data class Meta(val title: String, val thumb: String, val uploader: String, val duration: Long, val formats: List<Fmt>)
data class Plist(val title: String, val entries: List<Entry>)

fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k)

fun tokens(s: String): List<String> {
    val r = ArrayList<String>()
    val b = StringBuilder()
    var q = '\u0000'
    var has = false
    for (ch in s) {
        if (q != '\u0000') {
            if (ch == q) q = '\u0000' else b.append(ch)
        } else if (ch == '"' || ch == '\'') {
            q = ch
            has = true
        } else if (ch.isWhitespace()) {
            if (b.isNotEmpty() || has) {
                r.add(b.toString())
                b.setLength(0)
                has = false
            }
        } else {
            b.append(ch)
        }
    }
    if (b.isNotEmpty() || has) r.add(b.toString())
    return r
}

object Engine {
    val ready = MutableStateFlow(false)
    val error = MutableStateFlow("")
    val version = MutableStateFlow("")

    fun init(app: Application) {
        try {
            YoutubeDL.init(app)
            FFmpeg.init(app)
            Aria2c.init(app)
            error.value = ""
            ready.value = true
        } catch (e: Throwable) {
            error.value = e.message ?: e.javaClass.simpleName
        }
    }

    fun refreshVersion() {
        version.value = runCatching {
            YoutubeDL.execute(YoutubeDLRequest(emptyList<String>()).addOption("--version"), null, false, null).out.trim()
        }.getOrDefault("")
    }

    fun update(c: Context, channel: Int): String {
        val ch: YoutubeDL.UpdateChannel = when (channel) {
            1 -> YoutubeDL.UpdateChannel.NIGHTLY
            2 -> YoutubeDL.UpdateChannel.MASTER
            else -> YoutubeDL.UpdateChannel.STABLE
        }
        val st = YoutubeDL.updateYoutubeDL(c, ch)
        refreshVersion()
        return st?.name ?: ""
    }

    fun cancel(id: String) {
        YoutubeDL.destroyProcessById(id)
    }

    fun run(r: YoutubeDLRequest, id: String?, cb: ((Float, Long, String) -> Unit)?) = YoutubeDL.execute(r, id, false, cb)

    private fun net(c: Cfg, cookies: File): List<String> {
        val t = ArrayList<String>()
        if (c.proxy.isNotBlank()) { t.add("--proxy"); t.add(c.proxy.trim()) }
        if (c.cookies && cookies.exists()) { t.add("--cookies"); t.add(cookies.absolutePath) }
        return t
    }

    fun request(i: Item, c: Cfg, dir: File, cookies: File): YoutubeDLRequest {
        val t = ArrayList<String>()
        t.addAll(listOf("-o", File(dir, c.template.ifBlank { "%(title).150B [%(id)s].%(ext)s" }).path, "--no-mtime", "--newline"))
        if (c.merge.isNotEmpty()) t.addAll(listOf("--merge-output-format", c.merge))
        if (i.playlistItems.isNotBlank()) t.addAll(listOf("--yes-playlist", "--playlist-items", i.playlistItems))
        else if (c.noPlaylist) t.add("--no-playlist")
        if (c.compat) t.addAll(listOf("-S", "vcodec:h264,res,acodec:m4a"))
        if (c.restrict) t.add("--restrict-filenames")
        t.addAll(net(c, cookies))
        t.addAll(listOf("--retries", c.retries.toString(), "--fragment-retries", c.retries.toString()))
        if (c.fragments > 1) t.addAll(listOf("-N", c.fragments.toString()))
        if (c.limit.isNotBlank()) t.addAll(listOf("-r", c.limit.trim()))
        if (c.aria2) t.addAll(listOf("--downloader", "libaria2c.so"))
        if (c.subs) {
            t.addAll(listOf("--write-subs", "--sub-langs", c.subLangs.ifBlank { "all" }, "--convert-subs", "srt"))
            if (c.autoSubs) t.add("--write-auto-subs")
            if (c.embedSubs) t.add("--embed-subs")
        }
        if (c.thumb) t.addAll(listOf("--embed-thumbnail", "--convert-thumbnails", "jpg"))
        if (c.meta) t.add("--embed-metadata")
        if (c.sponsor) t.addAll(listOf("--sponsorblock-remove", c.sponsorCats.ifBlank { "sponsor" }))
        t.addAll(tokens(i.args))
        t.addAll(tokens(c.extra))
        t.add("--")
        return YoutubeDLRequest(i.url).addCommands(t)
    }

    fun dump(url: String, c: Cfg, cookies: File, id: String?, flat: Boolean, noPl: Boolean): JSONObject {
        val t = ArrayList<String>()
        t.addAll(listOf("-J", "--no-warnings"))
        if (flat) t.add("--flat-playlist")
        if (noPl) t.add("--no-playlist")
        t.addAll(net(c, cookies))
        t.addAll(tokens(c.extra))
        t.add("--")
        val r = YoutubeDL.execute(YoutubeDLRequest(url).addCommands(t), id, false, null)
        return parseOut(r.out)
    }

    private fun parseOut(out: String): JSONObject {
        val a = out.indexOf('{')
        val b = out.lastIndexOf('}')
        if (a < 0 || b <= a) throw IllegalStateException("No data")
        return JSONObject(out.substring(a, b + 1))
    }

    private fun thumb(j: JSONObject): String {
        val t = j.s("thumbnail")
        if (t.isNotEmpty()) return t
        val a = j.optJSONArray("thumbnails") ?: return ""
        return if (a.length() > 0) a.optJSONObject(a.length() - 1)?.s("url") ?: "" else ""
    }

    private fun fmt(f: JSONObject): Fmt {
        val h = f.optInt("height")
        val w = f.optInt("width")
        val size = f.optLong("filesize").takeIf { it > 0 } ?: f.optLong("filesize_approx")
        return Fmt(
            f.s("format_id"),
            f.s("ext"),
            f.s("resolution").ifEmpty { if (h > 0) "${w}x$h" else "" },
            h,
            f.optDouble("fps", 0.0),
            f.s("vcodec"),
            f.s("acodec"),
            size,
            f.optDouble("tbr", 0.0),
            f.s("format_note")
        )
    }

    fun meta(j: JSONObject): Meta {
        val fs = ArrayList<Fmt>()
        val a = j.optJSONArray("formats")
        if (a != null) for (i in 0 until a.length()) {
            val f = a.optJSONObject(i) ?: continue
            fs.add(fmt(f))
        }
        return Meta(j.s("title"), thumb(j), j.s("uploader").ifEmpty { j.s("channel") }, j.optLong("duration"), fs)
    }

    fun playlist(j: JSONObject): Plist {
        val out = ArrayList<Entry>()
        fun walk(o: JSONObject) {
            val es = o.optJSONArray("entries") ?: return
            for (i in 0 until es.length()) {
                val e = es.optJSONObject(i) ?: continue
                if (e.optJSONArray("entries") != null) {
                    walk(e)
                    continue
                }
                val url = e.s("url").ifEmpty { e.s("webpage_url") }
                out.add(Entry(out.size + 1, e.s("id").ifEmpty { url }, url, e.s("title"), e.optLong("duration"), thumb(e)))
            }
        }
        walk(j)
        return Plist(j.s("title"), out)
    }
}
