package app.mediadownloader

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage

@Composable
fun PlaylistScreen(vm: VM, cfg: Cfg) {
    val s by vm.pl.collectAsStateWithLifecycle()
    val clip = LocalClipboardManager.current
    var url by rememberSaveable { mutableStateOf("") }
    var preset by rememberSaveable(cfg.preset) { mutableStateOf(cfg.preset) }
    var from by rememberSaveable { mutableStateOf("") }
    var to by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Header(R.string.tab_pl)
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                url,
                { url = it },
                Modifier.weight(1f),
                label = { Text(stringResource(R.string.pl_url)) },
                singleLine = true,
                trailingIcon = {
                    IB(Icons.Filled.ContentPaste, R.string.paste) { clip.getText()?.text?.let { url = it.trim() } }
                }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.fetchPlaylist(url.trim()) }, enabled = url.isNotBlank() && !s.loading) {
                Icon(Icons.Filled.Search, stringResource(R.string.pl_fetch))
            }
        }
        if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(12.dp))
        if (s.error.isNotEmpty()) {
            Text(
                s.error,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(12.dp),
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (!s.loading && s.error.isEmpty() && s.url.isNotEmpty() && s.entries.isEmpty()) {
            Text(stringResource(R.string.pl_empty), modifier = Modifier.padding(12.dp))
        }
        if (s.entries.isNotEmpty()) {
            Column(Modifier.padding(horizontal = 12.dp)) {
                Text(
                    "${s.title.ifBlank { s.url }} · ${s.sel.size}/${s.entries.size}",
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.selAll() }) { Text(stringResource(R.string.sel_all)) }
                    TextButton(onClick = { vm.selNone() }) { Text(stringResource(R.string.sel_none)) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        from,
                        { from = it.filter(Char::isDigit) },
                        Modifier.width(88.dp),
                        label = { Text(stringResource(R.string.range_from)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        to,
                        { to = it.filter(Char::isDigit) },
                        Modifier.width(88.dp),
                        label = { Text(stringResource(R.string.range_to)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    TextButton(onClick = { vm.selRange(from.toIntOrNull() ?: 1, to.toIntOrNull() ?: s.entries.size) }) {
                        Text(stringResource(R.string.range_apply))
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    PresetPicker(cfg, preset) { preset = it }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = { vm.addSelected(preset) }, enabled = s.sel.isNotEmpty()) {
                        Text(stringResource(R.string.pl_add, s.sel.size))
                    }
                }
            }
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(s.entries, key = { it.index }) { e ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.toggle(e.index) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = e.index in s.sel, onCheckedChange = null)
                        Spacer(Modifier.width(8.dp))
                        AsyncImage(
                            model = e.thumb.ifEmpty { null },
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(width = 80.dp, height = 45.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${e.index}. ${e.title.ifBlank { e.url }}",
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (e.duration > 0) {
                                Text(
                                    hms(e.duration),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubsScreen(vm: VM, cfg: Cfg) {
    val subs by vm.subs.collectAsStateWithLifecycle()
    val busy by vm.busySubs.collectAsStateWithLifecycle()
    val msg by vm.subMsg.collectAsStateWithLifecycle()
    val clip = LocalClipboardManager.current
    var url by rememberSaveable { mutableStateOf("") }
    var preset by rememberSaveable(cfg.preset) { mutableStateOf(cfg.preset) }
    Column(Modifier.fillMaxSize()) {
        Header(R.string.tab_subs) {
            IB(Icons.Filled.Refresh, R.string.sub_check_all) { vm.checkAllSubs() }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Column {
                    OutlinedTextField(
                        url,
                        { url = it },
                        Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.sub_url)) },
                        singleLine = true,
                        trailingIcon = {
                            IB(Icons.Filled.ContentPaste, R.string.paste) { clip.getText()?.text?.let { url = it.trim() } }
                        }
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        PresetPicker(cfg, preset) { preset = it }
                        Spacer(Modifier.weight(1f))
                        Button(
                            onClick = {
                                vm.addSub(url, preset)
                                url = ""
                            },
                            enabled = url.isNotBlank()
                        ) { Text(stringResource(R.string.sub_add)) }
                    }
                    if (msg.isNotEmpty()) {
                        Text(
                            msg,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 8.dp),
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            items(subs, key = { it.id }) { s -> SubCard(s, s.id in busy, vm) }
        }
    }
}

@Composable
fun SubCard(s: Sub, busy: Boolean, vm: VM) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(
                s.title.ifBlank { s.url },
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val last = if (s.checked == 0L) stringResource(R.string.sub_never)
            else DateUtils.getRelativeTimeSpanString(s.checked, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
            Text(
                stringResource(R.string.sub_info, s.total, s.fresh()) + " · " + last,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                IB(Icons.Filled.Refresh, R.string.sub_check, !busy) { vm.checkSub(s.id) }
                IB(Icons.Filled.Download, R.string.sub_dl_new, s.fresh() > 0) { vm.downloadNew(s.id) }
                IB(Icons.Filled.DoneAll, R.string.sub_seen, s.fresh() > 0) { vm.markSeen(s.id) }
                IB(Icons.Filled.Delete, R.string.sub_del) { vm.delSub(s.id) }
            }
        }
    }
}
