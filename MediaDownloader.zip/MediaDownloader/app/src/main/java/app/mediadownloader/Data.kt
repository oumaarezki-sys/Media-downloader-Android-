package app.mediadownloader

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

object St {
    const val IDLE = "IDLE"
    const val QUEUED = "QUEUED"
    const val FETCHING = "FETCHING"
    const val RUNNING = "RUNNING"
    const val DONE = "DONE"
    const val FAILED = "FAILED"
    const val CANCELED = "CANCELED"
}

@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String = "",
    val thumb: String = "",
    val uploader: String = "",
    val duration: Long = 0,
    val status: String = St.QUEUED,
    val args: String = "",
    val playlistItems: String = "",
    val outUri: String = "",
    val outName: String = "",
    val size: Long = 0,
    val error: String = "",
    val log: String = "",
    val created: Long = System.currentTimeMillis()
)

@Entity(tableName = "subs")
data class Sub(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String = "",
    val args: String = "",
    val seen: String = "",
    val pending: String = "",
    val total: Int = 0,
    val checked: Long = 0
) {
    fun fresh(): Int = pending.lines().count { it.isNotBlank() }
}

@Dao
interface AppDao {
    @Query("SELECT * FROM items ORDER BY id DESC") fun items(): Flow<List<Item>>
    @Query("SELECT * FROM items WHERE id = :id") suspend fun item(id: Long): Item?
    @Insert suspend fun add(i: Item): Long
    @Update suspend fun save(i: Item)
    @Query("DELETE FROM items WHERE id = :id") suspend fun del(id: Long)
    @Query("DELETE FROM items WHERE status IN ('DONE','FAILED','CANCELED')") suspend fun clearEnded()
    @Query("UPDATE items SET status = 'QUEUED' WHERE status IN ('RUNNING','FETCHING')") suspend fun requeue()
    @Query("SELECT * FROM items WHERE status = 'QUEUED' ORDER BY id ASC") suspend fun queued(): List<Item>
    @Query("UPDATE items SET status = 'QUEUED', error = '' WHERE status IN ('IDLE','FAILED','CANCELED')") suspend fun startAll()
    @Query("UPDATE items SET status = 'CANCELED' WHERE status IN ('QUEUED','IDLE')") suspend fun cancelWaiting()
    @Query("SELECT * FROM subs ORDER BY id DESC") fun subs(): Flow<List<Sub>>
    @Query("SELECT * FROM subs") suspend fun subList(): List<Sub>
    @Query("SELECT * FROM subs WHERE id = :id") suspend fun sub(id: Long): Sub?
    @Insert suspend fun addSub(s: Sub): Long
    @Update suspend fun saveSub(s: Sub)
    @Query("DELETE FROM subs WHERE id = :id") suspend fun delSub(id: Long)
}

@Database(entities = [Item::class, Sub::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "md.db")
                .fallbackToDestructiveMigration()
                .build()
                .also { inst = it }
        }
    }
}

@Serializable
data class Preset(val name: String, val args: String)

@Serializable
data class Cfg(
    val tree: String = "",
    val parallel: Int = 2,
    val unmetered: Boolean = false,
    val autoStart: Boolean = true,
    val template: String = "%(title).150B [%(id)s].%(ext)s",
    val restrict: Boolean = false,
    val preset: String = "best",
    val presets: List<Preset> = emptyList(),
    val merge: String = "mp4",
    val compat: Boolean = false,
    val noPlaylist: Boolean = true,
    val aria2: Boolean = false,
    val fragments: Int = 4,
    val limit: String = "",
    val retries: Int = 10,
    val proxy: String = "",
    val cookies: Boolean = false,
    val subs: Boolean = false,
    val autoSubs: Boolean = false,
    val embedSubs: Boolean = false,
    val subLangs: String = "en.*,fr.*",
    val thumb: Boolean = false,
    val meta: Boolean = true,
    val sponsor: Boolean = false,
    val sponsorCats: String = "sponsor,selfpromo,interaction",
    val extra: String = "",
    val theme: Int = 0,
    val dynColor: Boolean = true,
    val channel: Int = 0,
    val autoUpdate: Boolean = true,
    val lastUpdate: Long = 0
)

val BUILTIN = listOf(
    Preset("best", "-f bv*+ba/b"),
    Preset("2160p", "-f bv*[height<=2160]+ba/b[height<=2160]"),
    Preset("1440p", "-f bv*[height<=1440]+ba/b[height<=1440]"),
    Preset("1080p", "-f bv*[height<=1080]+ba/b[height<=1080]"),
    Preset("720p", "-f bv*[height<=720]+ba/b[height<=720]"),
    Preset("480p", "-f bv*[height<=480]+ba/b[height<=480]"),
    Preset("360p", "-f bv*[height<=360]+ba/b[height<=360]"),
    Preset("MP3", "-f ba/b -x --audio-format mp3 --audio-quality 0"),
    Preset("M4A", "-f ba/b -x --audio-format m4a --audio-quality 0"),
    Preset("Opus", "-f ba/b -x --audio-format opus"),
    Preset("FLAC", "-f ba/b -x --audio-format flac"),
    Preset("WAV", "-f ba/b -x --audio-format wav"),
    Preset("AAC", "-f ba/b -x --audio-format aac --audio-quality 0")
)

fun allPresets(c: Cfg): List<Preset> = BUILTIN + c.presets

fun presetArgs(c: Cfg, name: String): String = allPresets(c).firstOrNull { it.name == name }?.args ?: BUILTIN[0].args

private val Context.store by preferencesDataStore("settings")
private val js = Json { ignoreUnknownKeys = true; encodeDefaults = true }

class Repo(private val c: Context) {
    private val key = stringPreferencesKey("cfg")

    private fun parse(s: String?): Cfg =
        s?.let { runCatching { js.decodeFromString(Cfg.serializer(), it) }.getOrNull() } ?: Cfg()

    val flow: Flow<Cfg> = c.store.data.map { parse(it[key]) }

    suspend fun update(f: (Cfg) -> Cfg) {
        c.store.edit { it[key] = js.encodeToString(Cfg.serializer(), f(parse(it[key]))) }
    }
}
