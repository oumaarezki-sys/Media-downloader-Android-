package app.mediadownloader

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.roundToInt

@Composable
private fun Sec(t: Int) {
    Text(
        stringResource(t),
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun Sw(t: Int, v: Boolean, on: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { on(!v) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(stringResource(t), Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = on)
    }
}

@Composable
private fun Tx(t: Int, v: String, on: (String) -> Unit) {
    var x by remember { mutableStateOf(v) }
    OutlinedTextField(
        x,
        {
            x = it
            on(it)
        },
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        label = { Text(stringResource(t)) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
    )
}

@Composable
private fun Sl(t: Int, v: Int, lo: Int, hi: Int, on: (Int) -> Unit) {
    var x by remember(v) { mutableFloatStateOf(v.toFloat()) }
    Column {
        Text(stringResource(t) + ": " + x.roundToInt())
        Slider(
            value = x,
            onValueChange = { x = it },
            valueRange = lo.toFloat()..hi.toFloat(),
            steps = hi - lo - 1,
            onValueChangeFinished = { on(x.roundToInt()) }
        )
    }
}

@Composable
private fun DdRow(t: Int, options: List<Pair<String, String>>, sel: String, on: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(t), Modifier.weight(1f))
        Dd(options.firstOrNull { it.first == sel }?.second ?: sel, options, sel, on)
    }
}

@Composable
fun SettingsScreen(vm: VM, c: Cfg) {
    val ctx = LocalContext.current
    val ver by vm.engineVersion.collectAsStateWithLifecycle()
    val ready by vm.ready.collectAsStateWithLifecycle()
    val busy by vm.engineBusy.collectAsStateWithLifecycle()
    val msg by vm.engineMsg.collectAsStateWithLifecycle()
    val treePick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    u,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
            }
            vm.set { it.copy(tree = u.toString()) }
        }
    }
    val cookiePick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.importCookies(u)
    }
    val merges = listOf("mp4" to "MP4", "mkv" to "MKV", "webm" to "WebM", "" to stringResource(R.string.auto))
    val themes = listOf(
        "0" to stringResource(R.string.theme_sys),
        "1" to stringResource(R.string.theme_light),
        "2" to stringResource(R.string.theme_dark)
    )
    val channels = listOf(
        "0" to stringResource(R.string.ch_stable),
        "1" to stringResource(R.string.ch_nightly),
        "2" to stringResource(R.string.ch_master)
    )
    Column(Modifier.fillMaxSize()) {
        Header(R.string.tab_set)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)
        ) {
            Sec(R.string.set_dl)
            Text(stringResource(R.string.set_folder), style = MaterialTheme.typography.bodyLarge)
            Text(
                if (c.tree.isEmpty()) stringResource(R.string.set_folder_def) else Uri.parse(c.tree).lastPathSegment ?: c.tree,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { treePick.launch(null) }) { Text(stringResource(R.string.set_choose)) }
                if (c.tree.isNotEmpty()) {
                    TextButton(onClick = { vm.set { it.copy(tree = "") } }) { Text(stringResource(R.string.set_reset)) }
                }
            }
            Sl(R.string.set_parallel, c.parallel, 1, 6) { v -> vm.set { it.copy(parallel = v) } }
            Sw(R.string.set_unmetered, c.unmetered) { v -> vm.set { it.copy(unmetered = v) } }
            Sw(R.string.set_autostart, c.autoStart) { v -> vm.set { it.copy(autoStart = v) } }
            Tx(R.string.set_template, c.template) { v -> vm.set { it.copy(template = v) } }
            Sw(R.string.set_restrict, c.restrict) { v -> vm.set { it.copy(restrict = v) } }

            Sec(R.string.set_video)
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.set_preset), Modifier.weight(1f))
                PresetPicker(c, c.preset) { v -> vm.set { it.copy(preset = v) } }
            }
            DdRow(R.string.set_merge, merges, c.merge) { v -> vm.set { it.copy(merge = v) } }
            Sw(R.string.set_compat, c.compat) { v -> vm.set { it.copy(compat = v) } }
            Sw(R.string.set_noplaylist, c.noPlaylist) { v -> vm.set { it.copy(noPlaylist = v) } }

            Sec(R.string.set_net)
            Sw(R.string.set_aria2, c.aria2) { v -> vm.set { it.copy(aria2 = v) } }
            Sl(R.string.set_frag, c.fragments, 1, 16) { v -> vm.set { it.copy(fragments = v) } }
            Sl(R.string.set_retries, c.retries, 0, 30) { v -> vm.set { it.copy(retries = v) } }
            Tx(R.string.set_limit, c.limit) { v -> vm.set { it.copy(limit = v) } }
            Tx(R.string.set_proxy, c.proxy) { v -> vm.set { it.copy(proxy = v) } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(if (c.cookies) R.string.set_cookies_on else R.string.set_cookies_off),
                    Modifier.weight(1f)
                )
                OutlinedButton(onClick = { cookiePick.launch(arrayOf("*/*")) }) { Text(stringResource(R.string.set_cookies_import)) }
                if (c.cookies) IB(Icons.Filled.Delete, R.string.set_cookies_clear) { vm.clearCookies() }
            }

            Sec(R.string.set_subs)
            Sw(R.string.set_subs_write, c.subs) { v -> vm.set { it.copy(subs = v) } }
            Sw(R.string.set_subs_auto, c.autoSubs) { v -> vm.set { it.copy(autoSubs = v) } }
            Sw(R.string.set_subs_embed, c.embedSubs) { v -> vm.set { it.copy(embedSubs = v) } }
            Tx(R.string.set_subs_langs, c.subLangs) { v -> vm.set { it.copy(subLangs = v) } }

            Sec(R.string.set_post)
            Sw(R.string.set_thumb, c.thumb) { v -> vm.set { it.copy(thumb = v) } }
            Sw(R.string.set_meta, c.meta) { v -> vm.set { it.copy(meta = v) } }
            Sw(R.string.set_sponsor, c.sponsor) { v -> vm.set { it.copy(sponsor = v) } }
            Tx(R.string.set_sponsor_cats, c.sponsorCats) { v -> vm.set { it.copy(sponsorCats = v) } }

            Sec(R.string.set_presets)
            c.presets.forEach { p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            p.args,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IB(Icons.Filled.Delete, R.string.a_remove) { vm.set { x -> x.copy(presets = x.presets - p) } }
                }
            }
            var pn by remember { mutableStateOf("") }
            var pa by remember { mutableStateOf("") }
            OutlinedTextField(
                pn,
                { pn = it },
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                label = { Text(stringResource(R.string.set_preset_name)) },
                singleLine = true
            )
            OutlinedTextField(
                pa,
                { pa = it },
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                label = { Text(stringResource(R.string.set_preset_args)) },
                singleLine = true
            )
            Button(
                onClick = {
                    val n = pn.trim()
                    val a = pa.trim()
                    if (n.isNotEmpty() && a.isNotEmpty() && BUILTIN.none { it.name.equals(n, true) }) {
                        vm.set { x -> x.copy(presets = x.presets.filter { it.name != n } + Preset(n, a)) }
                        pn = ""
                        pa = ""
                    }
                },
                enabled = pn.isNotBlank() && pa.isNotBlank()
            ) { Text(stringResource(R.string.add)) }

            Sec(R.string.set_adv)
            Tx(R.string.set_extra, c.extra) { v -> vm.set { it.copy(extra = v) } }

            Sec(R.string.set_ui)
            DdRow(R.string.set_theme, themes, c.theme.toString()) { v -> vm.set { it.copy(theme = v.toInt()) } }
            Sw(R.string.set_dynamic, c.dynColor) { v -> vm.set { it.copy(dynColor = v) } }

            Sec(R.string.set_engine)
            Text(stringResource(R.string.set_engine_ver, ver.ifEmpty { "…" }))
            DdRow(R.string.set_channel, channels, c.channel.toString()) { v -> vm.set { it.copy(channel = v.toInt()) } }
            Sw(R.string.set_autoupdate, c.autoUpdate) { v -> vm.set { it.copy(autoUpdate = v) } }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Button(onClick = { vm.updateEngine() }, enabled = ready && !busy) { Text(stringResource(R.string.set_update)) }
                Spacer(Modifier.width(12.dp))
                if (busy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                else if (msg.isNotEmpty()) Text(
                    when (msg) {
                        "DONE" -> stringResource(R.string.up_done)
                        "ALREADY_UP_TO_DATE" -> stringResource(R.string.up_ok)
                        else -> msg
                    },
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Sec(R.string.set_about)
            Text(stringResource(R.string.about_text), style = MaterialTheme.typography.bodyMedium)
            TextButton(
                onClick = {
                    launchSafe(
                        ctx,
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/mhogomchungu/media-downloader"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            ) { Text(stringResource(R.string.about_link)) }
        }
    }
}
